<?php
define("ADDRESS", $_SERVER['DOCUMENT_ROOT'].'/web/');
?>